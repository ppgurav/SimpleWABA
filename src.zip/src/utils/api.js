import axios from "axios"

export const api = axios.create({
//   baseURL: "https://api.mpocket.in", 
baseURL: "https://api.tickzap.com", 
// withCredentials: true,
})





